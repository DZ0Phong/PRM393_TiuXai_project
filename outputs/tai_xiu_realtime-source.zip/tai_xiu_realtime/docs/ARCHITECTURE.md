# Kiến trúc và luật

Flutter → Firebase Auth (email/password) → Callable Functions (asia-southeast1) → Firestore transactions. Flutter nhận snapshot Firestore cho phòng, phiên, cược cá nhân, ví và audit. Mọi write từ client bị rules chặn. Admin xác định bằng custom claim admin=true do script chạy trong môi trường tin cậy; không có trường role do user sửa.

## Schema
- users/{uid}: balance nguyên, createdAt. Khởi tạo một lần 10000 xu.
- users/{uid}/operations/{requestId}: nạp/rút và balance sau xử lý. requestId trùng trả kết quả cũ.
- rooms/main: roundId hiện hành.
- rounds/{id}: mode random/admin cố định, status open/settled, closesAt, betCount, dice, outcome, reason, settledBy.
- rounds/{id}/bets/{uid}: side, amount, credit, at, settledAt. UID là khóa chống cược lặp.
- auditLogs/{id}: actor UID, action, details, timestamp server. App không thể sửa/xóa. Người có quyền quản trị Firebase vẫn có thể sửa dữ liệu: đây chưa phải log chống giả mạo mật mã/WORM.

## Máy trạng thái
Admin tạo OPEN (30 giây) → deadline server khóa nhận cược → SETTLED. UI hiển thị đếm ngược để tham khảo; chỉ server xác định cược có hợp lệ. Sau deadline status có thể còn open trong lúc đợi chốt nhưng không nhận cược. Scheduler mỗi phút chốt random (có thể trễ hơn deadline); emulator không tự chạy Cloud Scheduler nên admin chốt thủ công. Admin mode bắt buộc chốt thủ công. Phiên tiếp theo chỉ mở sau khi phiên trước settled.

Giao dịch mở phiên đọc rooms/main và phiên cũ để ngăn mở hai phiên đồng thời. Giao dịch cược đọc ví/phiên/cược trước mọi write, kiểm deadline/số dư/số người, trừ xu + tạo cược + log cùng transaction. Settlement đọc toàn bộ cược và ví trước write, trả xu và đánh dấu settled nguyên tử; nếu gọi lại trả ok không trả xu thêm. Transaction tự retry khi tranh chấp; tối đa 100 người để giữ số write nhỏ trong MVP. Chưa benchmark tải.

## Luật công khai
Ba xúc xắc độc lập 1–6. Bộ ba (111,…,666) khiến cả Tài lẫn Xỉu thua. Các kết quả khác: tổng 4–10 Xỉu, 11–17 Tài. Mỗi phía có 105/216 kết quả thắng; bộ ba 6/216. Trừ toàn bộ cược ngay khi đặt. Thắng ghi có 2× cược gồm vốn (lãi ròng 1×); thua ghi có 0. Không phí. 10–1000 xu nguyên, một cược mỗi phiên, không sửa/hủy cược.

Random dùng crypto.randomInt phía server. Không có commit/reveal nên người chơi chưa tự chứng minh được tính công bằng mật mã; backend Firebase là nguồn tin cậy. Admin mode phải công bố trước cược và không được đổi mode; admin nhập 3 dice hợp lệ sau deadline, lý do 5–300 ký tự, danh tính/time/dice lưu ở phiên và audit công khai. Không hỗ trợ âm thầm đổi kết quả phiên random hoặc sửa phiên đã chốt.

## Quyền và dữ liệu công khai
Player đọc ví/cược của mình, phiên và audit. Admin đọc mọi ví/cược, mở/chốt phiên. Audit công khai UID và amount để demo minh bạch, không chứa email; cần thiết kế lại quyền riêng tư nếu mở rộng ngoài nhóm. Nạp/rút chỉ mint/burn xu, 10–1000/lần, số dư sau thao tác ví từ 0 đến 100000. Xu trả thưởng có thể vượt trần nạp. Nạp lặp nhiều lần được phép trong demo. Không gửi hoặc nhận tiền.

## API callable
ensureProfile({}); wallet({requestId,kind:deposit|withdraw,amount}); startRound({mode:random|admin}); placeBet({roundId,side:tai|xiu,amount}); settleRound({roundId,dice:[a,b,c],reason}). Tất cả cần đăng nhập; start/settle cần admin claim. UI tạo requestId mới cho mỗi ý định ví; khi tích hợp retry ngoài SDK phải giữ nguyên requestId, không tạo id mới.
