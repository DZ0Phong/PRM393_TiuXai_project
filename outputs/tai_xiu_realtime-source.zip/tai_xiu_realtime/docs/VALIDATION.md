# Kiểm tra thực tế — 12/10/2026

## Đạt
- Flutter dependency resolve thành công; pubspec.lock đi kèm.
- Flutter test: 1 test mặc định Emulator đạt. Đây là test cấu hình, không phải UI test.
- Node unit: 2 test đạt, duyệt đủ 216 tổ hợp xúc xắc, payout và validation.
- Backend syntax check và nạp module: đủ 6 exports ensureProfile/wallet/startRound/placeBet/settleRound/tick.
- Firebase Emulator integration: 2 test suite đạt (rules và callable), tổng khoảng 37 giây. Test 5 Player đồng thời, ví 9900 sau cược 100, 10100 sau thắng, 10200 sau hai request nạp chung ID chỉ cộng 100. Chặn Player mở phiên, mở trùng, cược muộn, chốt sớm, dice sai, rút âm; chốt lặp không cộng thêm; phiên random trả 3 dice hợp lệ. Audit đọc được khi đăng nhập, write bị chặn kể cả admin client.
- Flutter build web thành công, đầu ra build/web.
- Flutter build apk --debug thành công, đầu ra build/app/outputs/flutter-apk/app-debug.apk. Khoảng 158 MB, chưa ký release.
- npm audit --omit=dev: 0 cảnh báo ở runtime sau nâng firebase-admin 14.5 và firebase-functions 7.4.

## Điều kiện và giới hạn
SDK Flutter tại máy được gọi trực tiếp qua Dart/flutter_tools vì wrapper .bat ban đầu treo. Cần quyền truy cập cache SDK ngoài workspace; không phải lỗi source app. Build/test thực tế dùng SDK Flutter hiện có và Node 24.21, Java 21; deploy runtime yêu cầu Node 22. Emulator báo dùng Node24 do host; cần chạy lại trên Node22 trong CI trước deploy.

Full npm audit còn 16 cảnh báo (4 moderate, 12 high) trong cây công cụ phát triển/CLI, không thuộc runtime production. Chưa ép downgrade/override transitives vì có thể phá công cụ; rà soát và nâng CLI khi có bản sửa trước CI/triển khai chính thức.

Android build có cảnh báo plugin còn dùng Kotlin Gradle Plugin và unchecked Java operations; build vẫn thành công. Web có cảnh báo tham chiếu CupertinoIcons không đóng gói, app hiện không dùng CupertinoIcons. Chưa kiểm thử trên thiết bị Android hoặc trình duyệt bằng tương tác người dùng.

Chưa deploy Firebase thật; chưa test scheduler production, IAM/billing/App Check, tải 100 người, mất mạng trên thiết bị, khóa tài khoản hoặc quản trị ví nâng cao. Emulator integration chốt random thủ công; scheduler không chạy trong test này. Hai kết quả build chỉ chứng minh biên dịch, không thay nghiệm thu UI theo ACCEPTANCE.md.

Flutter analyze cuối cùng: No issues found. Loại functions/node_modules khỏi phạm vi Dart analyzer để không phân tích template Dart bên trong Firebase CLI.
